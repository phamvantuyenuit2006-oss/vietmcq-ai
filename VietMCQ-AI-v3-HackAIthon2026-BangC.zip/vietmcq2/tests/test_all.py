"""
tests/test_all.py — Test suite toàn diện VietMCQ-AI v3.0
25+ tests bao phủ mọi module.

Chạy: python3 tests/test_all.py
Yêu cầu: không cần GPU/model, chỉ cần pandas, numpy, loguru
"""
import sys, csv, json, tempfile, unittest
from pathlib import Path
from collections import Counter

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


# ════════════════════════════════════════════════════════════
class TestAnswerParser(unittest.TestCase):
    """15 cases cho parse_answer."""
    def setUp(self):
        from utils import parse_answer
        self.p = parse_answer

    def test_vn_colon(self):       self.assertEqual(self.p("ĐÁP ÁN: B"), "B")
    def test_vn_lower(self):       self.assertEqual(self.p("đáp án: c"), "C")
    def test_vn_mixed(self):       self.assertEqual(self.p("Đáp Án: D"), "D")
    def test_en_upper(self):       self.assertEqual(self.p("ANSWER: A"), "A")
    def test_en_lower(self):       self.assertEqual(self.p("answer: b"), "B")
    def test_bold_md(self):        self.assertEqual(self.p("Đáp án là **C**"), "C")
    def test_bold_star(self):      self.assertEqual(self.p("*D*"), "D")
    def test_paren(self):          self.assertEqual(self.p("Chọn (A)"), "A")
    def test_bracket(self):        self.assertEqual(self.p("[B]"), "B")
    def test_chon(self):           self.assertEqual(self.p("Vậy chọn C"), "C")
    def test_trailing(self):       self.assertEqual(self.p("Suy ra đáp án là D"), "D")
    def test_multiline(self):      self.assertEqual(self.p("Bước 1...\nBước 2...\nĐÁP ÁN: B"), "B")
    def test_empty(self):          self.assertEqual(self.p(""), "A")
    def test_no_match(self):       self.assertIn(self.p("không có gì"), "ABCD")
    def test_all_letters(self):
        for l in "ABCD":
            self.assertEqual(self.p(f"ĐÁP ÁN: {l}"), l)


# ════════════════════════════════════════════════════════════
class TestMajorityVote(unittest.TestCase):
    def setUp(self):
        from utils import majority_vote
        self.v = majority_vote

    def test_clear_majority(self):
        ans, cf = self.v(["A","A","B"])
        self.assertEqual(ans, "A"); self.assertAlmostEqual(cf, 2/3)

    def test_unanimous(self):
        ans, cf = self.v(["C","C","C"])
        self.assertEqual(ans, "C"); self.assertAlmostEqual(cf, 1.0)

    def test_empty(self):
        ans, cf = self.v([])
        self.assertEqual(ans, "A"); self.assertEqual(cf, 0.0)

    def test_tie_any_valid(self):
        ans, _ = self.v(["A","B"])
        self.assertIn(ans, "ABCD")

    def test_confidence_low(self):
        _, cf = self.v(["A","B","C"])
        self.assertLess(cf, 0.5)


# ════════════════════════════════════════════════════════════
class TestCSVLoader(unittest.TestCase):
    def setUp(self):
        from utils import load_test_csv
        self.load = load_test_csv

    def _tmp(self, content):
        f = tempfile.NamedTemporaryFile(mode="w", suffix=".csv",
                                        delete=False, encoding="utf-8")
        f.write(content); f.flush()
        return Path(f.name)

    def test_standard(self):
        p = self._tmp("qid,question,A,B,C,D\n1,Test?,Opt1,Opt2,Opt3,Opt4\n")
        df = self.load(p)
        self.assertEqual(len(df), 1)
        for col in ["qid","question","A","B","C","D"]:
            self.assertIn(col, df.columns)
        p.unlink()

    def test_no_qid(self):
        p = self._tmp("question,A,B,C,D\nTest?,O1,O2,O3,O4\n")
        df = self.load(p)
        self.assertIn("qid", df.columns)
        self.assertEqual(df["qid"].iloc[0], "1")
        p.unlink()

    def test_multiple_rows(self):
        lines = "qid,question,A,B,C,D\n"
        for i in range(10):
            lines += f'{i+1},Q{i}?,A{i},B{i},C{i},D{i}\n'
        p = self._tmp(lines)
        df = self.load(p)
        self.assertEqual(len(df), 10)
        p.unlink()

    def test_empty_choices(self):
        p = self._tmp("qid,question,A,B,C,D\n1,Q?,,,, \n")
        df = self.load(p)
        self.assertEqual(len(df), 1)
        p.unlink()


# ════════════════════════════════════════════════════════════
class TestBuildPromptText(unittest.TestCase):
    def test_full(self):
        import pandas as pd
        from utils import build_prompt_text
        row = pd.Series({"qid":"1","question":"Hỏi?",
                         "A":"Opt A","B":"Opt B","C":"Opt C","D":"Opt D"})
        t = build_prompt_text(row)
        self.assertIn("Hỏi?", t)
        self.assertIn("A. Opt A", t)
        self.assertIn("D. Opt D", t)

    def test_missing_choices(self):
        import pandas as pd
        from utils import build_prompt_text
        row = pd.Series({"qid":"1","question":"Hỏi?","A":"","B":"","C":"","D":""})
        t = build_prompt_text(row)
        self.assertIn("Hỏi?", t)


# ════════════════════════════════════════════════════════════
class TestSubjectDetector(unittest.TestCase):
    def setUp(self):
        from subject_detector import detect_subject, Subject
        self.detect = detect_subject
        self.Subject = Subject

    def test_math(self):
        subj, _ = self.detect("Hàm số y=x³-3x có bao nhiêu điểm cực trị?")
        self.assertEqual(subj, self.Subject.MATH)

    def test_physics(self):
        subj, _ = self.detect("Một vật có khối lượng 2kg, gia tốc 3m/s². Lực tác dụng là?")
        self.assertEqual(subj, self.Subject.PHYSICS)

    def test_chemistry(self):
        subj, _ = self.detect("Nguyên tử Na có số hiệu nguyên tử Z=11. Cấu hình electron là?")
        self.assertEqual(subj, self.Subject.CHEMISTRY)

    def test_biology(self):
        subj, _ = self.detect("Quá trình phiên mã tổng hợp phân tử ARN xảy ra ở đâu?")
        self.assertEqual(subj, self.Subject.BIOLOGY)

    def test_literature(self):
        subj, _ = self.detect("Tác phẩm Truyện Kiều được viết bởi tác giả nào?")
        self.assertEqual(subj, self.Subject.LITERATURE)

    def test_history(self):
        subj, _ = self.detect("Cách mạng tháng Tám 1945 thành công vào ngày nào?")
        self.assertEqual(subj, self.Subject.HISTORY)

    def test_it(self):
        subj, _ = self.detect("Độ phức tạp thuật toán tìm kiếm nhị phân là O(log n)?")
        self.assertEqual(subj, self.Subject.IT)

    def test_general_fallback(self):
        subj, conf = self.detect("Câu hỏi không rõ môn gì abcxyz")
        # Không crash, trả về kết quả hợp lệ
        self.assertIsNotNone(subj)
        self.assertGreaterEqual(conf, 0.0)


# ════════════════════════════════════════════════════════════
class TestKnowledgeBase(unittest.TestCase):
    def test_get_all_no_duplicate(self):
        from knowledge_base import get_all_kb
        docs = get_all_kb()
        self.assertGreater(len(docs), 30)
        # Không có duplicate
        self.assertEqual(len(docs), len(set(docs)))

    def test_subject_kb(self):
        from knowledge_base import get_kb_for_subject, KNOWLEDGE_BASE
        from subject_detector import Subject
        for subj in [Subject.MATH, Subject.PHYSICS, Subject.LITERATURE]:
            docs = get_kb_for_subject(subj)
            self.assertGreater(len(docs), 0)

    def test_kb_content_not_empty(self):
        from knowledge_base import MATH_KB, PHYSICS_KB, CHEMISTRY_KB
        for docs in [MATH_KB, PHYSICS_KB, CHEMISTRY_KB]:
            for d in docs:
                self.assertGreater(len(d), 20)


# ════════════════════════════════════════════════════════════
class TestOutputFormat(unittest.TestCase):
    def test_valid_pred_csv(self):
        import pandas as pd
        pred = pd.DataFrame({
            "qid":    [str(i) for i in range(1, 6)],
            "answer": ["A","B","C","D","A"],
        })
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
            pred.to_csv(f.name, index=False)
            p = Path(f.name)
        with open(p) as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        self.assertIn("qid", reader.fieldnames)
        self.assertIn("answer", reader.fieldnames)
        self.assertEqual(len(rows), 5)
        for row in rows:
            self.assertIn(row["answer"], "ABCD")
        p.unlink()

    def test_exactly_two_columns(self):
        import pandas as pd
        pred = pd.DataFrame({"qid":["1"],"answer":["B"],"extra":["x"]})
        # Output chỉ lấy 2 cột
        out = pred[["qid","answer"]]
        self.assertEqual(list(out.columns), ["qid","answer"])


# ════════════════════════════════════════════════════════════
class TestPromptBuilder(unittest.TestCase):
    def test_system_prompt_not_empty(self):
        from subject_detector import Subject, get_system_prompt
        for subj in Subject:
            s = get_system_prompt(subj)
            self.assertGreater(len(s), 20)
            self.assertIn("ĐÁP ÁN", s)

    def test_build_messages_structure(self):
        from subject_detector import Subject
        from prompt import build_messages
        msgs = build_messages("Test câu hỏi?\nA.X\nB.Y\nC.Z\nD.W",
                              "Kiến thức test", Subject.MATH, use_few_shot=False)
        self.assertEqual(len(msgs), 2)
        self.assertEqual(msgs[0]["role"], "system")
        self.assertEqual(msgs[1]["role"], "user")
        self.assertIn("Test câu hỏi?", msgs[1]["content"])

    def test_few_shot_adds_examples(self):
        from subject_detector import Subject
        from prompt import build_messages
        msgs_no_fs = build_messages("Q?","ctx", Subject.MATH, use_few_shot=False)
        msgs_fs    = build_messages("Q?","ctx", Subject.MATH, use_few_shot=True)
        # few_shot có thêm nội dung
        self.assertGreaterEqual(len(msgs_fs[1]["content"]),
                                 len(msgs_no_fs[1]["content"]))

    def test_context_injected(self):
        from subject_detector import Subject
        from prompt import build_messages
        ctx  = "Đây là kiến thức quan trọng ABC123"
        msgs = build_messages("Q?", ctx, Subject.GENERAL)
        self.assertIn("ABC123", msgs[1]["content"])


# ════════════════════════════════════════════════════════════
if __name__ == "__main__":
    loader = unittest.TestLoader()
    suite  = unittest.TestSuite()

    all_tests = [
        TestAnswerParser,
        TestMajorityVote,
        TestCSVLoader,
        TestBuildPromptText,
        TestSubjectDetector,
        TestKnowledgeBase,
        TestOutputFormat,
        TestPromptBuilder,
    ]
    for cls in all_tests:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    total  = result.testsRun
    passed = total - len(result.failures) - len(result.errors)
    print(f"\n{'='*55}")
    if result.wasSuccessful():
        print(f"✅  TẤT CẢ {total} TESTS PASSED — 3 LẦN ỔN ĐỊNH")
    else:
        print(f"❌  {passed}/{total} passed  |  "
              f"{len(result.failures)} failures  |  "
              f"{len(result.errors)} errors")
    print("="*55)
    sys.exit(0 if result.wasSuccessful() else 1)
