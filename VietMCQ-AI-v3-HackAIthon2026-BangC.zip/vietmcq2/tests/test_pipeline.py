"""
tests/test_pipeline.py — 20 Unit Tests toàn diện
Chạy: python3 tests/test_pipeline.py
Yêu cầu: không cần GPU, mock data, tất cả PASS
"""
import sys, os, csv, tempfile, unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


# ═══════════════════════════════════════════════════════════════
class TestAnswerParser(unittest.TestCase):
    """10 tests cho parse_answer"""

    def setUp(self):
        from utils import parse_answer
        self.p = parse_answer

    def test_dap_an_colon(self):
        self.assertEqual(self.p("suy luan...\nĐÁP ÁN: B"), "B")

    def test_dap_an_lowercase(self):
        self.assertEqual(self.p("đáp án: c"), "C")

    def test_dap_an_mixed(self):
        self.assertEqual(self.p("Đáp Án: D"), "D")

    def test_answer_english(self):
        self.assertEqual(self.p("ANSWER: A"), "A")

    def test_markdown_bold(self):
        self.assertEqual(self.p("Ket qua la **C**"), "C")

    def test_parenthesis(self):
        self.assertEqual(self.p("chon (B) la dung"), "B")

    def test_trailing_line(self):
        self.assertEqual(self.p("Vi vay chon\nA"), "A")

    def test_vay_pattern(self):
        self.assertEqual(self.p("Vậy đáp án là D"), "D")

    def test_empty_returns_default(self):
        self.assertEqual(self.p(""), "A")

    def test_all_letters(self):
        for letter in "ABCD":
            self.assertEqual(self.p(f"ĐÁP ÁN: {letter}"), letter)


# ═══════════════════════════════════════════════════════════════
class TestMajorityVote(unittest.TestCase):
    """5 tests cho majority_vote"""

    def setUp(self):
        from utils import majority_vote
        self.v = majority_vote

    def test_clear_majority(self):
        ans, conf = self.v(["A","A","B"])
        self.assertEqual(ans, "A")
        self.assertAlmostEqual(conf, 2/3)

    def test_unanimous(self):
        ans, conf = self.v(["C","C","C"])
        self.assertEqual(ans, "C")
        self.assertEqual(conf, 1.0)

    def test_empty(self):
        ans, conf = self.v([])
        self.assertEqual(ans, "A")
        self.assertEqual(conf, 0.0)

    def test_tie_returns_valid(self):
        ans, conf = self.v(["A","B"])
        self.assertIn(ans, "ABCD")

    def test_five_votes(self):
        ans, conf = self.v(["B","B","A","B","C"])
        self.assertEqual(ans, "B")
        self.assertAlmostEqual(conf, 3/5)


# ═══════════════════════════════════════════════════════════════
class TestCSVLoader(unittest.TestCase):
    """5 tests cho load_test_csv"""

    def setUp(self):
        from utils import load_test_csv
        self.load = load_test_csv

    def _write(self, content: str) -> Path:
        f = tempfile.NamedTemporaryFile(
            mode="w", suffix=".csv", delete=False, encoding="utf-8")
        f.write(content); f.flush()
        return Path(f.name)

    def test_standard_format(self):
        p = self._write(
            "qid,question,A,B,C,D\n"
            '1,"Ha Noi la thu do cua?","Viet Nam","Lao","Campuchia","Thai Lan"\n'
            '2,"2+2=?","3","4","5","6"\n'
        )
        df = self.load(p)
        self.assertEqual(len(df), 2)
        for col in ["qid","question","A","B","C","D"]:
            self.assertIn(col, df.columns)
        p.unlink()

    def test_auto_qid_generation(self):
        p = self._write("question,A,B,C,D\n\"Test?\",\"A1\",\"B1\",\"C1\",\"D1\"\n")
        df = self.load(p)
        self.assertIn("qid", df.columns)
        p.unlink()

    def test_utf8_sig_encoding(self):
        p = self._write("\ufeffqid,question,A,B,C,D\n1,\"Test\",\"A\",\"B\",\"C\",\"D\"\n")
        df = self.load(p)
        self.assertEqual(len(df), 1)
        p.unlink()

    def test_missing_choices_empty_string(self):
        p = self._write("qid,question,A,B,C,D\n1,\"Q?\",\"Opt A\",\"\",\"\",\"\"\n")
        df = self.load(p)
        self.assertEqual(df.iloc[0]["A"], "Opt A")
        p.unlink()

    def test_output_columns_always_present(self):
        p = self._write("qid,question,A,B,C,D\n1,\"Q\",\"a\",\"b\",\"c\",\"d\"\n")
        df = self.load(p)
        for col in ["qid","question","A","B","C","D"]:
            self.assertIn(col, df.columns)
        p.unlink()


# ═══════════════════════════════════════════════════════════════
class TestSubjectDetector(unittest.TestCase):
    """5 tests cho subject detection"""

    def setUp(self):
        from subject_detector import detect_subject, Subject
        self.detect  = detect_subject
        self.Subject = Subject

    def test_detect_math(self):
        subj, conf = self.detect("Đạo hàm của hàm số f(x)=x³-3x là?\nA. 3x²-3  B. x²-3  C. 3x+3  D. 3x²")
        self.assertEqual(subj, self.Subject.MATH)

    def test_detect_chemistry(self):
        subj, _ = self.detect("Nguyên tử Na có số hiệu nguyên tử Z=11. Cấu hình electron là?")
        self.assertEqual(subj, self.Subject.CHEMISTRY)

    def test_detect_history(self):
        subj, _ = self.detect("Cách mạng tháng Tám năm 1945 thành công vào ngày nào?")
        self.assertEqual(subj, self.Subject.HISTORY)

    def test_detect_literature(self):
        subj, _ = self.detect("Tác phẩm Tắt đèn do ai sáng tác? A. Nam Cao B. Ngô Tất Tố")
        self.assertEqual(subj, self.Subject.LITERATURE)

    def test_detect_returns_valid_subject(self):
        subj, conf = self.detect("Câu hỏi ngẫu nhiên không rõ môn")
        self.assertIn(subj, list(self.Subject))
        self.assertGreaterEqual(conf, 0.0)


# ═══════════════════════════════════════════════════════════════
class TestOutputFormat(unittest.TestCase):
    """3 tests cho output format"""

    def test_pred_csv_format(self):
        import pandas as pd
        pred = pd.DataFrame({"qid":["1","2","3","4"], "answer":["A","B","C","D"]})
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
            pred.to_csv(f.name, index=False); p = Path(f.name)
        with open(p) as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        self.assertIn("qid",    reader.fieldnames)
        self.assertIn("answer", reader.fieldnames)
        for row in rows:
            self.assertIn(row["answer"], "ABCD")
        p.unlink()

    def test_all_valid_answers(self):
        from utils import parse_answer
        for x in ["A","B","C","D"]:
            self.assertIn(parse_answer(f"ĐÁP ÁN: {x}"), "ABCD")

    def test_invalid_fallback(self):
        from utils import parse_answer
        result = parse_answer("xyz không có đáp án nào")
        self.assertIn(result, "ABCD")


# ═══════════════════════════════════════════════════════════════
if __name__ == "__main__":
    loader = unittest.TestLoader()
    suite  = unittest.TestSuite()
    for cls in [
        TestAnswerParser,
        TestMajorityVote,
        TestCSVLoader,
        TestSubjectDetector,
        TestOutputFormat,
    ]:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("\n" + "="*55)
    total = result.testsRun
    if result.wasSuccessful():
        print(f"✅  TẤT CẢ {total} TESTS PASSED  ✅")
    else:
        print(f"❌  {len(result.failures)} failures, {len(result.errors)} errors / {total} tests")
    print("="*55)
    sys.exit(0 if result.wasSuccessful() else 1)
