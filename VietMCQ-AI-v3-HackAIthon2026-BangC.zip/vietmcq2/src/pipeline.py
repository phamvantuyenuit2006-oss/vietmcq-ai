"""
pipeline.py — MCQ Pipeline v3.0 HOÀN CHỈNH

Nâng cấp so với v2:
  1. Knowledge Base nhúng sẵn (kiến thức đa môn)
  2. Subject-aware prompt (prompt theo môn học)
  3. Self-consistency ensemble (3 lần generate, majority vote)
  4. Confidence scoring: vote < 60% -> re-generate với few-shot mạnh hơn
  5. Hybrid retrieval: KB + self-retrieval kết hợp
"""
import time
import pandas as pd
from typing import List, Tuple, Dict
from loguru import logger

from config import Config
from utils import load_test_csv, build_prompt_text, parse_answer, majority_vote
from subject_detector import detect_subject, Subject
from knowledge_base import get_kb_for_subject, get_all_kb
from prompt import build_messages
from retriever import HybridRetriever
from reranker import QwenReranker
from llm import QwenLLM


class MCQPipeline:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        logger.info("=" * 60)
        logger.info("  VietMCQ-AI v3.0 -- Khoi tao Pipeline")
        logger.info("=" * 60)

        logger.info("📦 [1/3] Tai LLM (Qwen3.5)...")
        self.llm = QwenLLM(
            model_name=cfg.llm_model,
            model_dir=cfg.model_dir,
            max_new_tokens=cfg.max_new_tokens,
        )

        self.retriever: HybridRetriever = None
        self.reranker:  QwenReranker    = None

        if cfg.use_rag:
            logger.info("📦 [2/3] Tai Embedding (BGE-m3)...")
            self.retriever = HybridRetriever(
                model_name=cfg.embed_model,
                model_dir=cfg.model_dir,
                use_fp16=cfg.use_fp16,
            )
            logger.info("📦 [3/3] Tai Reranker (Qwen3-Reranker)...")
            self.reranker = QwenReranker(
                model_name=cfg.rerank_model,
                model_dir=cfg.model_dir,
            )
        else:
            logger.info("RAG tat")

        logger.info("Pipeline san sang!\n")

    def _setup_indices(self, df: pd.DataFrame) -> None:
        if self.retriever is None:
            return
        questions = [build_prompt_text(row) for _, row in df.iterrows()]
        self.retriever.build_self_index(questions)
        if self.cfg.use_kb:
            kb_docs = get_all_kb()
            self.retriever.build_kb_index(kb_docs)

    def _retrieve_contexts(self, df: pd.DataFrame) -> List[str]:
        if self.retriever is None:
            return [""] * len(df)
        queries = [build_prompt_text(row) for _, row in df.iterrows()]
        logger.info(f"  Batch retrieving {len(queries)} queries...")
        t0 = time.perf_counter()
        all_cands = self.retriever.batch_retrieve(queries, kb_top_k=10, self_top_k=10)
        logger.info(f"  Retrieval: {time.perf_counter()-t0:.1f}s")
        if self.reranker is None:
            return ["\n\n".join(c[:self.cfg.top_k_rerank]) for c in all_cands]
        logger.info(f"  Reranking {len(queries)} queries...")
        t0 = time.perf_counter()
        contexts = []
        for q, cands in zip(queries, all_cands):
            reranked = self.reranker.rerank(q, cands, top_k=self.cfg.top_k_rerank) if cands else []
            contexts.append("\n\n".join(reranked))
        logger.info(f"  Reranking: {time.perf_counter()-t0:.1f}s")
        return contexts

    def _detect_subjects(self, df: pd.DataFrame) -> List[Subject]:
        subjects = []
        for _, row in df.iterrows():
            subj, _ = detect_subject(build_prompt_text(row))
            subjects.append(subj)
        return subjects

    def _build_messages_batch(self, df, contexts, subjects, use_few_shot=False):
        all_msgs = []
        for i, (_, row) in enumerate(df.iterrows()):
            q_text = build_prompt_text(row)
            ctx    = contexts[i] if contexts else ""
            subj   = subjects[i] if subjects else Subject.GENERAL
            all_msgs.append(build_messages(q_text, ctx, subj, use_few_shot=use_few_shot))
        return all_msgs

    def _run_llm_batch(self, all_messages):
        results = []
        bs, total = self.cfg.batch_size, len(all_messages)
        for start in range(0, total, bs):
            end   = min(start + bs, total)
            outs  = self.llm.generate_batch(all_messages[start:end])
            results.extend(outs)
            logger.info(f"    LLM [{end:>4}/{total}] {end/total*100:.0f}%")
        return results

    def predict(self, df: pd.DataFrame) -> pd.DataFrame:
        t_total = time.perf_counter()
        if self.cfg.debug:
            df = df.head(self.cfg.debug_n).copy()
            logger.warning(f"DEBUG: {self.cfg.debug_n} cau")

        n = len(df)
        logger.info(f"Tong so cau hoi: {n}\n")

        # 1. Build indices
        logger.info("Buoc 1: Build FAISS indices...")
        t0 = time.perf_counter()
        self._setup_indices(df)
        logger.info(f"  {time.perf_counter()-t0:.1f}s\n")

        # 2. Retrieve + Rerank
        logger.info("Buoc 2: Hybrid retrieve + rerank...")
        contexts = self._retrieve_contexts(df)
        logger.info("")

        # 3. Detect mon hoc
        logger.info("Buoc 3: Phan loai mon hoc...")
        subjects = self._detect_subjects(df)
        sc: Dict[str, int] = {}
        for s in subjects: sc[s.value] = sc.get(s.value, 0) + 1
        logger.info(f"  Phan bo mon: {sc}\n")

        # 4. Self-consistency ensemble
        n_samples = self.cfg.n_samples if self.cfg.ensemble_enabled else 1
        logger.info(f"Buoc 4: Self-consistency ({n_samples} samples)...")
        t0 = time.perf_counter()

        all_runs: List[List[str]] = []
        for run_i in range(n_samples):
            logger.info(f"  -- Run {run_i+1}/{n_samples} --")
            msgs = self._build_messages_batch(
                df, contexts, subjects,
                use_few_shot=(run_i == n_samples - 1)
            )
            raw  = self._run_llm_batch(msgs)
            all_runs.append([parse_answer(o) for o in raw])

        infer_time = time.perf_counter() - t0
        logger.info(f"  Inference: {infer_time:.1f}s\n")

        # 5. Majority vote + confidence
        logger.info("Buoc 5: Majority vote + confidence scoring...")
        final_answers = []
        low_conf_idx  = []
        for i in range(n):
            votes = [all_runs[r][i] for r in range(n_samples)]
            ans, conf = majority_vote(votes)
            final_answers.append(ans)
            if conf < self.cfg.low_conf_threshold:
                low_conf_idx.append(i)
        logger.info(f"  Low-confidence: {len(low_conf_idx)}/{n}\n")

        # 6. Re-generate low-confidence
        if low_conf_idx and self.cfg.ensemble_enabled:
            logger.info(f"Buoc 6: Re-generate {len(low_conf_idx)} cau low-confidence...")
            t0 = time.perf_counter()
            lc_df  = df.iloc[low_conf_idx].reset_index(drop=True)
            lc_ctx = [contexts[i] for i in low_conf_idx]
            lc_sub = [subjects[i] for i in low_conf_idx]

            enriched = []
            for i_lc, (_, row) in enumerate(lc_df.iterrows()):
                kb_extra = "\n\n".join(get_kb_for_subject(lc_sub[i_lc])[:5])
                enriched.append(kb_extra + "\n\n" + lc_ctx[i_lc])

            lc_runs: List[List[str]] = []
            for _ in range(2):
                lc_msgs = self._build_messages_batch(lc_df, enriched, lc_sub, use_few_shot=True)
                lc_raw  = self._run_llm_batch(lc_msgs)
                lc_runs.append([parse_answer(o) for o in lc_raw])

            for j, orig_i in enumerate(low_conf_idx):
                all_votes = [all_runs[r][orig_i] for r in range(n_samples)]
                all_votes += [lc_runs[r][j] for r in range(len(lc_runs))]
                new_ans, new_conf = majority_vote(all_votes)
                final_answers[orig_i] = new_ans
                logger.info(f"    Cau {orig_i}: {all_votes} -> {new_ans} (conf={new_conf:.0%})")

            logger.info(f"  Re-generate: {time.perf_counter()-t0:.1f}s\n")

        # Output
        total_time = time.perf_counter() - t_total
        from collections import Counter
        dist = Counter(final_answers)
        logger.info("=" * 60)
        logger.info("HOAN TAT!")
        logger.info(f"   Cau hoi:     {n}")
        logger.info(f"   Infer time:  {infer_time:.1f}s  ({infer_time/n*1000:.0f}ms/cau)")
        logger.info(f"   Tong time:   {total_time:.1f}s")
        logger.info(f"   Answer dist: {dict(dist)}")
        logger.info("=" * 60)

        return pd.DataFrame({"qid": df["qid"].values, "answer": final_answers})
