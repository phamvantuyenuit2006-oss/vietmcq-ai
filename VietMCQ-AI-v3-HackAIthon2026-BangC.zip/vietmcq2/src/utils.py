"""
utils.py — Tiện ích: CSV loader đa format, answer parser siêu robust
"""
import re, pandas as pd
from pathlib import Path
from typing import Optional, List, Dict, Tuple
from collections import Counter
from loguru import logger

# ── CSV auto-detect ─────────────────────────────────────────
_QID  = ["qid","id","question_id","stt","câu","no","số","index"]
_QCOL = ["question","câu hỏi","nội dung","text","content","q","problem","câu","đề"]
_OPTS = {
    "A": ["a","choice_a","option_a","answer_a","pa","đáp án a","lựa chọn a","phương án a"],
    "B": ["b","choice_b","option_b","answer_b","pb","đáp án b","lựa chọn b","phương án b"],
    "C": ["c","choice_c","option_c","answer_c","pc","đáp án c","lựa chọn c","phương án c"],
    "D": ["d","choice_d","option_d","answer_d","pd","đáp án d","lựa chọn d","phương án d"],
}

def _find(cols: Dict[str, str], cands: List[str]) -> Optional[str]:
    for c in cands:
        if c in cols: return cols[c]
    return None

def load_test_csv(path: Path) -> pd.DataFrame:
    """Load CSV, auto-detect encoding và format cột."""
    df = None
    for enc in ["utf-8", "utf-8-sig", "utf-16", "cp1252", "latin1"]:
        try:
            df = pd.read_csv(path, encoding=enc)
            break
        except Exception:
            continue
    if df is None:
        raise ValueError(f"Không đọc được: {path}")

    df.columns = df.columns.str.strip()
    cols = {c.lower().strip(): c for c in df.columns}

    qid_col = _find(cols, _QID)
    q_col   = _find(cols, _QCOL)

    out = pd.DataFrame()
    out["qid"] = df[qid_col].astype(str).str.strip() if qid_col else [str(i+1) for i in range(len(df))]

    out["question"] = df[q_col].astype(str).str.strip() if q_col else ""

    for letter, cands in _OPTS.items():
        col = _find(cols, cands)
        out[letter] = df[col].astype(str).str.strip().replace("nan","") if col else ""

    logger.info(f"  CSV: {len(out)} rows | cols={list(df.columns)[:6]}")
    return out


def build_prompt_text(row: pd.Series) -> str:
    """Ghép câu hỏi + A/B/C/D thành text đầy đủ."""
    parts = []
    q = str(row.get("question","")).strip()
    if q and q != "nan": parts.append(q)
    for l in "ABCD":
        v = str(row.get(l,"")).strip()
        if v and v not in ("nan",""):
            parts.append(f"{l}. {v}")
    return "\n".join(parts) if parts else str(dict(row))


# ── Answer parser siêu robust ────────────────────────────────
_PATTERNS = [
    r"ĐÁP\s*ÁN\s*[:\-=]\s*\**\s*([A-D])\s*\**",
    r"đáp\s*án\s*[:\-=]\s*\**\s*([A-D])\s*\**",
    r"Đáp\s*Án\s*[:\-=]\s*\**\s*([A-D])\s*\**",
    r"ANSWER\s*[:\-=]\s*\**\s*([A-D])\s*\**",
    r"Answer\s*[:\-=]\s*\**\s*([A-D])\s*\**",
    r"answer\s*[:\-=]\s*([A-D])",
    r"\*\*\s*([A-D])\s*\*\*",
    r"chọn\s+đáp\s+án\s+([A-D])",
    r"chọn\s+([A-D])\b",
    r"lựa chọn[:\s]+([A-D])",
    r"câu trả lời[:\s]+([A-D])",
    r"kết quả[:\s]+([A-D])",
    r"Vậy\s+(?:đáp\s+án\s+(?:là|đúng|đúng\s+là)\s+)?([A-D])\b",
    r"vậy\s+(?:đáp\s+án\s+(?:là|đúng|đúng\s+là)\s+)?([A-D])\b",
    r"Do\s+đó.*?([A-D])[.)]\s",
    r"Suy\s+ra.*?([A-D])[.)]\s",
    r"\(([A-D])\)",
    r"\[([A-D])\]",
    r"(?:^|\n)\s*([A-D])\s*$",
    r"(?:^|\n)\s*([A-D])[.)]\s*$",
    r"\b([A-D])\s*$",
]

def parse_answer(text: str, default: str = "A") -> str:
    if not text or not text.strip():
        return default
    # Tìm toàn bộ text
    for pat in _PATTERNS:
        m = re.search(pat, text, re.IGNORECASE | re.MULTILINE)
        if m:
            a = m.group(1).upper()
            if a in "ABCD": return a
    # Tìm từ cuối lên
    for line in reversed(text.strip().split("\n")):
        line = line.strip()
        if not line: continue
        for pat in _PATTERNS:
            m = re.search(pat, line, re.IGNORECASE)
            if m:
                a = m.group(1).upper()
                if a in "ABCD": return a
    # Fallback: đếm trong 100 ký tự cuối
    tail = text.strip()[-100:].upper()
    counts = {c: tail.count(c) for c in "ABCD"}
    best = max(counts, key=counts.get)
    if counts[best] > 0: return best
    return default


def majority_vote(answers: List[str]) -> Tuple[str, float]:
    """Trả về (đáp án, confidence). confidence = tỉ lệ vote."""
    valid = [a for a in answers if a in "ABCD"]
    if not valid: return "A", 0.0
    cnt = Counter(valid)
    best, count = cnt.most_common(1)[0]
    return best, count / len(valid)
