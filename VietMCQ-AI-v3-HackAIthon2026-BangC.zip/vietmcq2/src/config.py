"""
config.py — Cấu hình trung tâm VietMCQ-AI v3.0
"""
import os, torch
from dataclasses import dataclass, field
from pathlib import Path


def _vram_gb() -> float:
    try:
        if torch.cuda.is_available():
            _, total = torch.cuda.mem_get_info(0)
            return total / 1024**3
    except Exception:
        pass
    return 0.0


def _auto_llm(vram: float) -> str:
    if vram >= 14: return "Qwen/Qwen3.5-7B-Instruct"
    if vram >= 6:  return "Qwen/Qwen3.5-3B-Instruct"
    return "Qwen/Qwen3.5-1.5B-Instruct"


@dataclass
class Config:
    # ── Paths ───────────────────────────────────────────────
    data_dir:      Path = Path("/data")
    output_dir:    Path = Path("/output")
    model_dir:     Path = Path("/app/models")
    kb_dir:        Path = Path("/app/knowledge")   # knowledge base

    # ── Models ──────────────────────────────────────────────
    llm_model:    str = ""
    embed_model:  str = "BAAI/bge-m3"
    rerank_model: str = "Qwen/Qwen3-Reranker-0.6B"

    # ── RAG ─────────────────────────────────────────────────
    use_rag:      bool = True
    use_kb:       bool = True    # dùng knowledge base nhúng sẵn
    top_k_ret:    int  = 30      # retrieve nhiều hơn để rerank
    top_k_rerank: int  = 6

    # ── Inference ───────────────────────────────────────────
    batch_size:     int   = 8
    max_new_tokens: int   = 220
    use_fp16:       bool  = True

    # ── Self-consistency ensemble ────────────────────────────
    n_samples:        int  = 3      # số lần generate để vote
    ensemble_enabled: bool = True

    # ── Confidence scoring ──────────────────────────────────
    low_conf_threshold: float = 0.6   # vote < 60% → re-generate với few-shot

    # ── Debug ───────────────────────────────────────────────
    debug:   bool = False
    debug_n: int  = 20

    def __post_init__(self):
        self.data_dir   = Path(self.data_dir)
        self.output_dir = Path(self.output_dir)
        self.model_dir  = Path(self.model_dir)
        self.kb_dir     = Path(self.kb_dir)
        vram = _vram_gb()
        if not self.llm_model:
            self.llm_model = _auto_llm(vram)
        # Auto batch-size
        if vram >= 24:   self.batch_size = 16
        elif vram >= 14: self.batch_size = 8
        elif vram >= 6:  self.batch_size = 4
        else:            self.batch_size = 1

    @classmethod
    def from_env(cls) -> "Config":
        c = cls()
        if os.getenv("LLM_MODEL"): c.llm_model = os.getenv("LLM_MODEL")
        c.use_rag  = os.getenv("USE_RAG",  "1") == "1"
        c.use_kb   = os.getenv("USE_KB",   "1") == "1"
        c.n_samples = int(os.getenv("N_SAMPLES", "3"))
        c.ensemble_enabled = os.getenv("ENSEMBLE", "1") == "1"
        c.debug    = os.getenv("DEBUG", "0") == "1"
        return c
