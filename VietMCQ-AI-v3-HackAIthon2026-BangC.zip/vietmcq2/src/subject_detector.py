"""
subject_detector.py — Phân loại môn học và chọn prompt/strategy phù hợp

Đây là một trong những nâng cấp quan trọng nhất:
- Câu Toán cần suy luận số học từng bước
- Câu Văn học cần nhớ tác giả, tác phẩm, trích dẫn
- Câu Lịch sử cần nhớ mốc thời gian, sự kiện
- Câu Hóa học cần cân bằng phương trình, tính mol
→ Prompt khác nhau → accuracy tăng đáng kể
"""
import re
from enum import Enum
from typing import Tuple


class Subject(Enum):
    MATH        = "math"
    PHYSICS     = "physics"
    CHEMISTRY   = "chemistry"
    BIOLOGY     = "biology"
    LITERATURE  = "literature"
    HISTORY     = "history"
    GEOGRAPHY   = "geography"
    ENGLISH     = "english"
    IT          = "it"
    CIVIC       = "civic"
    GENERAL     = "general"


# ── Keyword sets theo môn ───────────────────────────────────
_RULES = [
    (Subject.MATH, [
        r"hàm số", r"đạo hàm", r"tích phân", r"giới hạn", r"ma trận",
        r"phương trình", r"bất phương trình", r"số nguyên tố", r"tổ hợp",
        r"xác suất", r"logarit", r"lũy thừa", r"tam giác", r"hình học",
        r"diện tích", r"thể tích", r"véc-tơ", r"vector", r"dãy số",
        r"\bsin\b", r"\bcos\b", r"\btan\b", r"cot\b", r"π", r"∑",
        r"\d+\s*[+\-×÷]\s*\d+", r"bằng bao nhiêu", r"tính giá trị",
        r"số nghiệm", r"giải hệ", r"cực trị", r"tiệm cận",
    ]),
    (Subject.PHYSICS, [
        r"vận tốc", r"gia tốc", r"lực", r"điện trường", r"từ trường",
        r"điện áp", r"cường độ dòng điện", r"điện trở", r"công suất",
        r"sóng", r"dao động", r"photon", r"hạt nhân", r"phóng xạ",
        r"nhiệt lượng", r"động năng", r"thế năng", r"Newton",
        r"Ohm", r"Faraday", r"tụ điện", r"cuộn cảm", r"quang học",
    ]),
    (Subject.CHEMISTRY, [
        r"nguyên tố", r"nguyên tử", r"phân tử", r"ion", r"mol",
        r"phản ứng", r"oxi hóa", r"khử", r"axit", r"bazơ", r"muối",
        r"este", r"amin", r"protein", r"polyme", r"hidrocacbon",
        r"benzen", r"ancol", r"andehit", r"xeton", r"số hiệu",
        r"cấu hình electron", r"liên kết", r"hóa trị", r"điện phân",
        r"H₂O", r"CO₂", r"NaOH", r"HCl", r"H₂SO₄",
    ]),
    (Subject.BIOLOGY, [
        r"tế bào", r"ADN", r"ARN", r"gen\b", r"nhiễm sắc thể",
        r"di truyền", r"tiến hóa", r"quang hợp", r"hô hấp tế bào",
        r"enzym", r"axit amin", r"đột biến gen", r"đột biến NST",
        r"sinh thái", r"quần thể", r"hệ sinh thái", r"miễn dịch",
        r"Menđen", r"Mendelian", r"kiểu gen", r"kiểu hình",
        r"phiên mã", r"dịch mã", r"ribosome", r"codon", r"nucleotid",
        r"lục lạp", r"ty thể", r"nhân tế bào", r"màng tế bào",
        r"sinh học", r"cơ thể sống", r"NST", r"ATP",
    ]),
    (Subject.LITERATURE, [
        r"tác phẩm", r"tác giả", r"nhân vật", r"truyện", r"thơ",
        r"tiểu thuyết", r"bài thơ", r"đoạn trích", r"văn học",
        r"Nguyễn Du", r"Hồ Xuân Hương", r"Nam Quốc Sơn Hà",
        r"Truyện Kiều", r"Tắt đèn", r"Chí Phèo", r"trào lưu",
        r"phong trào thơ mới", r"hiện thực", r"lãng mạn",
        r"câu thơ", r"khổ thơ", r"điệp ngữ", r"ẩn dụ", r"hoán dụ",
    ]),
    (Subject.HISTORY, [
        r"năm \d{3,4}", r"thế kỷ", r"triều đại", r"khởi nghĩa",
        r"cách mạng", r"chiến tranh", r"kháng chiến", r"thực dân",
        r"đế quốc", r"phong kiến", r"Điện Biên Phủ", r"1945",
        r"Hồ Chí Minh", r"Đảng Cộng sản", r"Việt Minh",
        r"triều Nguyễn", r"triều Lý", r"triều Trần", r"nhà Lê",
        r"sự kiện lịch sử", r"hiệp định", r"hội nghị",
    ]),
    (Subject.GEOGRAPHY, [
        r"địa lý", r"khí hậu", r"địa hình", r"sông", r"núi",
        r"vùng kinh tế", r"dân số", r"đô thị hóa", r"tài nguyên",
        r"thiên nhiên", r"miền Bắc", r"miền Nam", r"Tây Nguyên",
        r"đồng bằng", r"cao nguyên", r"bán đảo", r"vĩ độ", r"kinh độ",
    ]),
    (Subject.ENGLISH, [
        r"\b(which|what|who|where|when|how|why)\b",
        r"\b(is|are|was|were|has|have|had|will|would|can|could|shall|should)\b",
        r"\b(the|a|an)\b.*\b(the|a|an)\b",
        r"passive voice", r"tense", r"grammar",
        r"[A-Z][a-z]+ [A-Z][a-z]+",   # English proper nouns
    ]),
    (Subject.IT, [
        r"thuật toán", r"lập trình", r"ngôn ngữ lập trình",
        r"cơ sở dữ liệu", r"mạng máy tính", r"giao thức",
        r"hệ điều hành", r"phần mềm", r"CPU", r"RAM", r"TCP",
        r"IP", r"HTTP", r"SQL", r"Python", r"Java", r"độ phức tạp",
        r"đệ quy", r"sắp xếp", r"tìm kiếm", r"cấu trúc dữ liệu",
    ]),
    (Subject.CIVIC, [
        r"pháp luật", r"hiến pháp", r"quyền công dân", r"nghĩa vụ",
        r"nhà nước", r"chính sách", r"kinh tế thị trường",
        r"đạo đức", r"công dân", r"xã hội chủ nghĩa",
    ]),
]


def detect_subject(text: str) -> Tuple[Subject, float]:
    """
    Nhận diện môn học từ văn bản câu hỏi.
    Trả về (Subject, confidence_score).
    """
    text_lower = text.lower()
    scores = {s: 0 for s in Subject}

    for subject, patterns in _RULES:
        for pat in patterns:
            if re.search(pat, text_lower, re.IGNORECASE):
                scores[subject] += 1

    best = max(scores, key=scores.get)
    total = sum(scores.values())
    conf = scores[best] / total if total > 0 else 0.0

    if scores[best] == 0:
        return Subject.GENERAL, 0.0
    return best, conf


# ── System prompts chuyên biệt theo môn ─────────────────────
SYSTEM_PROMPTS = {
    Subject.MATH: """Bạn là giáo viên Toán cấp THPT và Đại học tại Việt Nam, chuyên giải các bài toán trắc nghiệm.
Quy tắc: Tính toán từng bước rõ ràng. Kiểm tra lại kết quả. Loại trừ đáp án sai bằng phân tích. Luôn kết thúc bằng: ĐÁP ÁN: X""",

    Subject.PHYSICS: """Bạn là giáo viên Vật lý cấp THPT và Đại học tại Việt Nam.
Quy tắc: Xác định công thức phù hợp. Thay số và tính toán. Chú ý đơn vị. Luôn kết thúc bằng: ĐÁP ÁN: X""",

    Subject.CHEMISTRY: """Bạn là giáo viên Hóa học cấp THPT và Đại học tại Việt Nam.
Quy tắc: Cân bằng phương trình hóa học. Tính theo mol. Áp dụng quy tắc hóa trị đúng. Luôn kết thúc bằng: ĐÁP ÁN: X""",

    Subject.BIOLOGY: """Bạn là giáo viên Sinh học cấp THPT và Đại học tại Việt Nam.
Quy tắc: Nhớ chính xác cơ chế sinh học. Phân biệt các khái niệm gần giống nhau. Luôn kết thúc bằng: ĐÁP ÁN: X""",

    Subject.LITERATURE: """Bạn là giáo viên Ngữ văn cấp THPT tại Việt Nam, am hiểu văn học Việt Nam và thế giới.
Quy tắc: Nhớ chính xác tác giả, năm sáng tác, nhân vật, chủ đề tư tưởng. Phân tích nghệ thuật đặc sắc. Luôn kết thúc bằng: ĐÁP ÁN: X""",

    Subject.HISTORY: """Bạn là giáo viên Lịch sử cấp THPT tại Việt Nam, thông thạo lịch sử Việt Nam và thế giới.
Quy tắc: Nhớ chính xác mốc thời gian, nhân vật lịch sử, diễn biến sự kiện. Phân tích nguyên nhân-kết quả. Luôn kết thúc bằng: ĐÁP ÁN: X""",

    Subject.GEOGRAPHY: """Bạn là giáo viên Địa lý cấp THPT tại Việt Nam.
Quy tắc: Nắm vững đặc điểm tự nhiên, kinh tế-xã hội từng vùng. Số liệu địa lý chính xác. Luôn kết thúc bằng: ĐÁP ÁN: X""",

    Subject.ENGLISH: """You are an English language expert and teacher in Vietnam, specializing in multiple-choice English grammar and vocabulary questions.
Rules: Identify the grammatical structure. Apply the correct rule. Eliminate wrong options. Always end with: ĐÁP ÁN: X""",

    Subject.IT: """Bạn là chuyên gia Công nghệ thông tin và giảng viên CNTT tại Việt Nam.
Quy tắc: Áp dụng kiến thức kỹ thuật chính xác. Tính toán độ phức tạp nếu cần. Luôn kết thúc bằng: ĐÁP ÁN: X""",

    Subject.CIVIC: """Bạn là giáo viên Giáo dục công dân và Pháp luật tại Việt Nam.
Quy tắc: Dựa trên quy định pháp luật Việt Nam hiện hành. Phân biệt các khái niệm chính xác. Luôn kết thúc bằng: ĐÁP ÁN: X""",

    Subject.GENERAL: """Bạn là chuyên gia giải đề thi trắc nghiệm tại Việt Nam với kiến thức toàn diện mọi môn học.
Quy tắc: Đọc kỹ câu hỏi. Suy luận logic từng bước. Loại trừ đáp án sai. Luôn kết thúc bằng: ĐÁP ÁN: X""",
}


def get_system_prompt(subject: Subject) -> str:
    return SYSTEM_PROMPTS.get(subject, SYSTEM_PROMPTS[Subject.GENERAL])
