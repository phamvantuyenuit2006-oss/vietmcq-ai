"""
knowledge_base.py — Knowledge Base tiếng Việt nhúng sẵn trong Docker

Chiến lược: Nhúng sẵn kiến thức cốt lõi của từng môn vào image
→ Không cần internet, không cần corpus ngoài
→ Retrieval context chất lượng cao hơn self-retrieval thuần túy

Nội dung được tổng hợp từ:
  - Chương trình THPT Việt Nam (Bộ GD&ĐT)
  - Kiến thức đại học năm 1-2 (toán, lý, hóa, sinh, CNTT)
  - Lịch sử, địa lý Việt Nam
  - Văn học Việt Nam và thế giới
"""
from typing import List

# ═══════════════════════════════════════════════════════════════
# TOÁN HỌC
# ═══════════════════════════════════════════════════════════════
MATH_KB = [
    # Đạo hàm
    "Đạo hàm của hàm số y=xⁿ là y'=n·xⁿ⁻¹. Đạo hàm của y=eˣ là y'=eˣ. Đạo hàm y=ln(x) là y'=1/x. Đạo hàm y=sin(x) là y'=cos(x). Đạo hàm y=cos(x) là y'=-sin(x).",
    "Quy tắc đạo hàm: (u+v)'=u'+v'; (uv)'=u'v+uv'; (u/v)'=(u'v-uv')/v². Đạo hàm hàm hợp: [f(g(x))]'=f'(g(x))·g'(x).",
    "Hàm số đồng biến khi f'(x)>0. Hàm số nghịch biến khi f'(x)<0. Cực đại khi f'(x) đổi dấu từ + sang -. Cực tiểu khi f'(x) đổi dấu từ - sang +.",
    # Tích phân
    "Tích phân cơ bản: ∫xⁿdx=xⁿ⁺¹/(n+1)+C. ∫eˣdx=eˣ+C. ∫(1/x)dx=ln|x|+C. ∫sin(x)dx=-cos(x)+C. ∫cos(x)dx=sin(x)+C.",
    "Tích phân xác định ∫ₐᵇf(x)dx = F(b)-F(a) trong đó F là nguyên hàm của f. Ý nghĩa hình học: diện tích hình phẳng giới hạn bởi đường cong.",
    # Lũy thừa-logarit
    "Tính chất logarit: log_a(xy)=log_a(x)+log_a(y). log_a(x/y)=log_a(x)-log_a(y). log_a(xⁿ)=n·log_a(x). Đổi cơ số: log_a(b)=log_c(b)/log_c(a).",
    "Phương trình mũ: aˣ=aʸ ↔ x=y (a>0, a≠1). Phương trình logarit: log_a(x)=log_a(y) ↔ x=y (x,y>0).",
    # Xác suất
    "Xác suất cổ điển: P(A)=số kết quả thuận lợi/tổng số kết quả. P(A∪B)=P(A)+P(B)-P(A∩B). Nếu A và B độc lập: P(A∩B)=P(A)·P(B).",
    "Tổ hợp C(n,k)=n!/(k!(n-k)!). Chỉnh hợp A(n,k)=n!/(n-k)!. Hoán vị P(n)=n!. Nhị thức Newton: (a+b)ⁿ=∑C(n,k)·aⁿ⁻ᵏ·bᵏ.",
    # Hình học
    "Thể tích hình cầu: V=(4/3)πR³. Diện tích mặt cầu: S=4πR². Thể tích khối chóp: V=(1/3)·S_đáy·h. Thể tích hình trụ: V=πR²h.",
    "Vector trong không gian: độ dài |AB|=√((x₂-x₁)²+(y₂-y₁)²+(z₂-z₁)²). Tích vô hướng: a⃗·b⃗=|a||b|cos θ. Hai vector vuông góc khi tích vô hướng =0.",
    # Giới hạn
    "Các giới hạn đặc biệt: lim(x→0) sin(x)/x = 1. lim(x→∞)(1+1/x)ˣ = e ≈ 2.718. lim(x→0)(eˣ-1)/x = 1. lim(x→0) ln(1+x)/x = 1.",
    # Phương trình bậc 2
    "Phương trình bậc 2: ax²+bx+c=0. Δ=b²-4ac. Nghiệm: x=(-b±√Δ)/2a. Vi-et: x₁+x₂=-b/a; x₁·x₂=c/a. Δ>0: 2 nghiệm phân biệt. Δ=0: nghiệm kép. Δ<0: vô nghiệm thực.",
]

# ═══════════════════════════════════════════════════════════════
# VẬT LÝ
# ═══════════════════════════════════════════════════════════════
PHYSICS_KB = [
    "Định luật Newton 1: Vật giữ nguyên trạng thái chuyển động nếu không có lực tác dụng (quán tính). Newton 2: F=ma. Newton 3: Lực và phản lực bằng nhau, ngược chiều.",
    "Công thức động lực học: v=v₀+at. s=v₀t+½at². v²=v₀²+2as. Ném ngang: x=v₀t, y=½gt². Ném xiên: tầm xa X=v₀²sin(2α)/g.",
    "Định luật Ohm: I=U/R. Điện trở nối tiếp: R=R₁+R₂+...Rₙ. Song song: 1/R=1/R₁+1/R₂+...Công suất điện: P=UI=I²R=U²/R. Điện năng: W=Pt=UIt.",
    "Sóng cơ: v=λf. T=1/f. Sóng dừng: l=nλ/2 (hai đầu cố định), l=(2n-1)λ/4 (một đầu cố định). Giao thoa sóng: tăng cường khi Δd=nλ, triệt tiêu khi Δd=(n+1/2)λ.",
    "Dao động điều hòa: x=Acos(ωt+φ). v=-Aωsin(ωt+φ). a=-Aω²cos(ωt+φ)=-ω²x. Năng lượng: E=½mω²A²=½kA². Con lắc lò xo: ω=√(k/m), T=2π√(m/k). Con lắc đơn: T=2π√(L/g).",
    "Thuyết tương đối Einstein: E=mc². Năng lượng toàn phần: E=mc²/√(1-v²/c²). Hệ thức Einstein: E²=(pc)²+(mc²)². Năng lượng hạt nhân: ΔE=Δm·c².",
    "Quang học: Định luật Snell: n₁sinθ₁=n₂sinθ₂. Gương cầu: 1/f=1/d+1/d'=2/R. Thấu kính: 1/f=1/d+1/d'. Số phóng đại: k=-d'/d.",
    "Hiệu ứng quang điện: hf=A+½mv²_max. Năng lượng photon: E=hf=hc/λ. h=6.626×10⁻³⁴ J·s. Bước sóng giới hạn: λ₀=hc/A.",
    "Định luật Faraday: e=-N·dΦ/dt. Cảm ứng từ dây thẳng: B=μ₀I/(2πr). Lực Lorentz: F=qv×B. Lực Ampere: F=BIl·sinθ.",
    "Nhiệt động lực học: ΔU=Q+A. Hiệu suất máy nhiệt: η=1-T₂/T₁ (Carnot). Entropy luôn tăng trong hệ cô lập. Phương trình khí lí tưởng: pV=nRT.",
]

# ═══════════════════════════════════════════════════════════════
# HÓA HỌC
# ═══════════════════════════════════════════════════════════════
CHEMISTRY_KB = [
    "Bảng tuần hoàn: Chu kỳ = số lớp electron. Nhóm = số electron lớp ngoài cùng. Tính kim loại tăng theo chiều tăng bán kính nguyên tử. Độ âm điện tăng từ trái sang phải, từ dưới lên trên.",
    "Cấu hình electron: 1s 2s 2p 3s 3p 4s 3d 4p 5s 4d 5p 6s 4f 5d 6p. Na(11): 1s²2s²2p⁶3s¹. Cl(17): 1s²2s²2p⁶3s²3p⁵. Fe(26): 1s²2s²2p⁶3s²3p⁶3d⁶4s².",
    "Phản ứng oxi hóa-khử: chất oxi hóa nhận e⁻ (số oxi hóa giảm). Chất khử cho e⁻ (số oxi hóa tăng). Cân bằng theo phương pháp thăng bằng electron.",
    "Axit mạnh: HCl, HBr, HI, HNO₃, H₂SO₄, HClO₄. Bazơ mạnh: NaOH, KOH, Ca(OH)₂, Ba(OH)₂. pH=-log[H⁺]. pH+pOH=14 ở 25°C. pH<7: axit, pH=7: trung tính, pH>7: kiềm.",
    "Hidrocacbon: Ankan CₙH₂ₙ₊₂ (no, không vòng). Anken CₙH₂ₙ (1 nối đôi C=C). Ankyn CₙH₂ₙ₋₂ (1 nối ba C≡C). Benzen C₆H₆ (vòng thơm). Phản ứng đặc trưng: ankan-thế; anken-cộng; benzen-thế ái điện tử.",
    "Este: R-COO-R'. Thủy phân este trong môi trường kiềm (xà phòng hóa): R-COO-R' + NaOH → R-COONa + R'OH. Phản ứng este hóa: RCOOH + R'OH ⇌ RCOOR' + H₂O (xt H₂SO₄ đặc, đun nóng).",
    "Amin: R-NH₂ (bậc 1). Amin có tính bazơ do cặp e⁻ tự do trên N. Amino axit: chứa cả nhóm -NH₂ và -COOH. Peptit: liên kết giữa các amino axit qua liên kết peptit -CO-NH-.",
    "Polyme: trùng hợp (nối đôi mở ra) và trùng ngưng (kèm tách H₂O/HCl). PE: (-CH₂-CH₂-)ₙ. PVC: (-CH₂-CHCl-)ₙ. Nylon-6,6: trùng ngưng hexametylendiamin và axit adipic.",
    "Điện phân: catot (cực âm) xảy ra quá trình khử. Anot (cực dương) xảy ra quá trình oxi hóa. Công thức Faraday: m=AIt/(nF). F=96500 C/mol.",
    "Tính toán mol: n=m/M. n=V/22.4 (đktc). n=C_M·V. Bảo toàn khối lượng: Σm_chất đầu = Σm_sản phẩm. Bảo toàn electron: Σe cho = Σe nhận.",
]

# ═══════════════════════════════════════════════════════════════
# SINH HỌC
# ═══════════════════════════════════════════════════════════════
BIOLOGY_KB = [
    "Cấu trúc ADN: chuỗi xoắn kép, liên kết hiđrô giữa A-T (2 liên kết), G-X (3 liên kết). Nguyên tắc bổ sung: A-T, G-X. Tự nhân đôi ADN theo nguyên tắc bổ sung và bán bảo tồn.",
    "Phiên mã: ADN → mARN (trong nhân tế bào). Dịch mã: mARN → Protein (ở ribosome). Bộ ba mở đầu: AUG (methionin). Bộ ba kết thúc: UAA, UAG, UGA.",
    "Quy luật Menđen 1 (phân ly): Aa × Aa → 1AA:2Aa:1aa (kiểu gen), 3 trội:1 lặn (kiểu hình). Quy luật Menđen 2 (phân ly độc lập): AaBb × AaBb → tỉ lệ 9:3:3:1.",
    "Di truyền liên kết giới tính: gen trên NST X. Bố XY cho X hoặc Y. Mẹ XX cho X. Bệnh máu khó đông, mù màu: gen lặn trên X, nam mắc nhiều hơn nữ.",
    "Đột biến gen: thay thế, thêm, mất nucleotid. Đột biến NST: đột biến số lượng (thể đa bội, thể dị bội) và cấu trúc (mất đoạn, lặp đoạn, đảo đoạn, chuyển đoạn).",
    "Quang hợp: 6CO₂ + 6H₂O + ánh sáng → C₆H₁₂O₆ + 6O₂. Pha sáng: diễn ra ở tilacoit, tạo ATP và NADPH, giải phóng O₂. Pha tối (chu trình Calvin): diễn ra ở chất nền lục lạp, cố định CO₂.",
    "Hô hấp tế bào: C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + năng lượng (38 ATP). Đường phân (cytoplasm): 2 ATP. Chu trình Krebs (matrix): 2 ATP. Chuỗi vận chuyển electron (màng ty thể): 34 ATP.",
    "Tiến hóa Darwin: biến dị → chọn lọc tự nhiên → thích nghi. Quần thể là đơn vị tiến hóa. Các nhân tố tiến hóa: đột biến, chọn lọc, di nhập gen, phiêu bạt di truyền.",
    "Hệ sinh thái: Quần xã + môi trường vô sinh. Chuỗi thức ăn: sản xuất → tiêu thụ bậc 1 → bậc 2 → bậc 3. Năng lượng giảm 90% qua mỗi bậc dinh dưỡng. Chu trình vật chất khép kín, dòng năng lượng một chiều.",
]

# ═══════════════════════════════════════════════════════════════
# VĂN HỌC VIỆT NAM
# ═══════════════════════════════════════════════════════════════
LITERATURE_KB = [
    # Tác phẩm - tác giả
    "Truyện Kiều (Đoạn trường tân thanh) — Nguyễn Du (1765-1820). 3254 câu thơ lục bát. Nhân vật: Thúy Kiều, Thúy Vân, Kim Trọng, Từ Hải, Mã Giám Sinh, Tú Bà. Chủ đề: số phận người phụ nữ tài sắc trong xã hội phong kiến.",
    "Nam Quốc Sơn Hà — Lý Thường Kiệt (1019-1105). Bài thơ thần, tuyên ngôn độc lập đầu tiên của Việt Nam. Đọc trên sông Như Nguyệt (1077) khi chống Tống.",
    "Bình Ngô Đại Cáo — Nguyễn Trãi (1380-1442). Tuyên ngôn độc lập lần 2. Viết sau chiến thắng quân Minh năm 1428. 'Như nước Đại Việt ta từ trước, Vốn xưng nền văn hiến đã lâu'.",
    "Tắt đèn — Ngô Tất Tố (1893-1954). Tiểu thuyết hiện thực 1939. Nhân vật chị Dậu, anh Dậu. Nạn sưu thuế thực dân - phong kiến. 'Con giun xéo lắm cũng quằn'.",
    "Chí Phèo — Nam Cao (1917-1951). Truyện ngắn 1941. Chí Phèo bị tha hóa bởi xã hội phong kiến. Thị Nở. Bá Kiến. 'Ai cho tao lương thiện?'. Bi kịch bị cự tuyệt quyền làm người.",
    "Truyện Lục Vân Tiên — Nguyễn Đình Chiểu (1822-1888). Thơ Nôm, truyện thơ. Nhân vật: Lục Vân Tiên, Kiều Nguyệt Nga. Đề cao trung, hiếu, tiết, nghĩa.",
    "Vợ nhặt — Kim Lân (1920-2007). Truyện ngắn 1954. Bối cảnh nạn đói 1945. Nhân vật Tràng, người vợ nhặt, bà cụ Tứ. Giá trị nhân văn: tình người trong hoàn cảnh khốn khó.",
    "Đất nước — Nguyễn Khoa Điềm (1943). Trích trường ca 'Mặt đường khát vọng' (1974). 'Đất nước là nơi em đánh rơi chiếc khăn trong nỗi nhớ thầm'. Tư tưởng Đất Nước của Nhân Dân.",
    "Tây Tiến — Quang Dũng (1921-1988). Bài thơ 1948. Viết về đoàn quân Tây Tiến hành quân qua Tây Bắc. Hình tượng người lính hào hoa, bi tráng. 'Tây Tiến đoàn binh không mọc tóc'.",
    # Biện pháp tu từ
    "Biện pháp tu từ: Ẩn dụ (so sánh ngầm, không dùng 'như'). Hoán dụ (gọi tên bộ phận thay toàn thể). Nhân hóa (gán tính người cho vật). Điệp ngữ (lặp từ/cụm từ). Đảo ngữ (đảo trật tự từ). Liệt kê. Câu hỏi tu từ.",
    "Phong trào Thơ Mới (1932-1945): Xuân Diệu ('Ông hoàng thơ tình'), Huy Cận, Hàn Mặc Tử, Nguyễn Bính, Chế Lan Viên. Đặc điểm: cái tôi cá nhân, tự do, lãng mạn, ảnh hưởng Pháp.",
    "Văn học hiện thực phê phán (1930-1945): Nam Cao, Ngô Tất Tố, Vũ Trọng Phụng, Nguyễn Công Hoan. Phản ánh xã hội thực dân phong kiến, thân phận người nghèo.",
]

# ═══════════════════════════════════════════════════════════════
# LỊCH SỬ VIỆT NAM
# ═══════════════════════════════════════════════════════════════
HISTORY_KB = [
    "Năm 939: Ngô Quyền đánh bại quân Nam Hán trên sông Bạch Đằng, kết thúc 1000 năm Bắc thuộc. Năm 968: Đinh Bộ Lĩnh thống nhất, lập nhà Đinh, quốc hiệu Đại Cồ Việt. Năm 1010: Lý Thái Tổ dời đô về Thăng Long.",
    "Năm 1226: Trần Thái Tông lên ngôi, nhà Trần. Ba lần kháng chiến chống Mông-Nguyên: 1258, 1285, 1288. Hưng Đạo Vương Trần Quốc Tuấn chỉ huy. Chiến thắng Bạch Đằng 1288.",
    "Năm 1407: nhà Minh xâm lược, đô hộ Đại Việt 20 năm. Năm 1418: Lê Lợi khởi nghĩa Lam Sơn. Năm 1428: đánh đuổi quân Minh, lập nhà Lê, Nguyễn Trãi viết Bình Ngô Đại Cáo.",
    "Pháp xâm lược Việt Nam: 1858 tấn công Đà Nẵng, 1859 chiếm Sài Gòn. Hiệp ước Nhâm Tuất 1862: nhường 3 tỉnh Nam Kỳ. 1884: toàn bộ Việt Nam trở thành thuộc địa Pháp (Hiệp ước Patenôtre).",
    "Cách mạng tháng Tám 1945: Nhật đầu hàng Đồng Minh (8/1945) tạo thời cơ. Tổng khởi nghĩa 19/8/1945 tại Hà Nội. 2/9/1945 Hồ Chí Minh đọc Tuyên ngôn Độc lập tại Quảng trường Ba Đình.",
    "Kháng chiến chống Pháp (1945-1954): Chiến dịch Việt Bắc 1947 (Pháp thua). Chiến dịch Biên Giới 1950. Chiến dịch Điện Biên Phủ 7/5/1954: Pháp thua quyết định. Hiệp định Giơnevơ 7/1954: chia cắt tại vĩ tuyến 17.",
    "Kháng chiến chống Mỹ (1954-1975): Ngày 30/4/1975 giải phóng Sài Gòn (Chiến dịch Hồ Chí Minh). Tổng Tiến công Tết Mậu Thân 1968. Hiệp định Paris 1973. Đại thắng mùa Xuân 1975.",
    "Đảng Cộng sản Việt Nam thành lập: 3/2/1930 tại Hồng Kông. Hội nghị hợp nhất do Nguyễn Ái Quốc (Hồ Chí Minh) chủ trì. Cương lĩnh chính trị đầu tiên được thông qua.",
    "Lịch sử thế giới: Cách mạng Pháp 1789 (Tự do-Bình đẳng-Bác ái). Cách mạng tháng 10 Nga 1917 (Lenin, Bolshevik). Thế chiến I (1914-1918). Thế chiến II (1939-1945, Hitler-Đức thua). Liên Xô tan rã 1991.",
]

# ═══════════════════════════════════════════════════════════════
# ĐỊA LÝ
# ═══════════════════════════════════════════════════════════════
GEOGRAPHY_KB = [
    "Việt Nam: 331.212 km², chữ S, 15°00'N - 23°23'N. Bắc giáp Trung Quốc (1.281 km), Tây giáp Lào (2.130 km), Campuchia (1.228 km), Đông-Nam giáp Biển Đông (3.260 km đường bờ biển).",
    "7 vùng kinh tế Việt Nam: Trung du và miền núi phía Bắc (nhiều khoáng sản, thủy điện). Đồng bằng sông Hồng (lúa, công nghiệp). Bắc Trung Bộ. Duyên hải Nam Trung Bộ (ngư nghiệp, du lịch). Tây Nguyên (cà phê, cao su, bauxite). Đông Nam Bộ (kinh tế mạnh nhất). ĐBSCL (vựa lúa, thủy sản).",
    "Khí hậu Việt Nam: nhiệt đới gió mùa ẩm. Miền Bắc: 4 mùa, mùa đông có sương mù. Miền Nam: 2 mùa mưa-khô. Tây Nguyên: mùa mưa tháng 5-10. Hà Nội trung bình 23-24°C. TP.HCM 27°C.",
    "Sông lớn Việt Nam: Sông Hồng (1.149 km trong VN, bắt nguồn Trung Quốc). Sông Mê Kông (ĐBSCL, dài nhất Đông Nam Á). Sông Đà (nhánh lớn nhất sông Hồng, thủy điện Sơn La, Hòa Bình). Sông Đồng Nai.",
    "Dân số Việt Nam (2024): ~100 triệu người. 54 dân tộc (Kinh chiếm 86%). Mật độ 280 người/km². Đô thị hóa ~40%. Hà Nội: ~8.5 triệu. TP.HCM: ~9.5 triệu. Đà Nẵng, Hải Phòng, Cần Thơ là đô thị loại 1.",
    "Khí hậu thế giới: Nhiệt đới (xích đạo). Cận nhiệt đới khô (sa mạc Sahara). Ôn đới. Hàn đới (vùng cực). Gió mùa châu Á do chênh lệch nhiệt độ lục địa-đại dương. El Niño: nước Thái Bình Dương ấm lên, ảnh hưởng toàn cầu.",
]

# ═══════════════════════════════════════════════════════════════
# CÔNG NGHỆ THÔNG TIN
# ═══════════════════════════════════════════════════════════════
IT_KB = [
    "Độ phức tạp thuật toán Big-O: O(1) hằng số. O(log n) nhị phân. O(n) tuyến tính. O(n log n) quick/merge sort. O(n²) bubble/insertion sort. O(2ⁿ) đệ quy Fibonacci naive. O(n!) bài toán TSP brute force.",
    "Mô hình OSI 7 tầng: 1-Physical (cáp, bit). 2-Data Link (MAC, Ethernet, switch). 3-Network (IP, router). 4-Transport (TCP/UDP, port). 5-Session. 6-Presentation (SSL, mã hóa). 7-Application (HTTP, FTP, DNS, SMTP).",
    "Cơ sở dữ liệu quan hệ: Khóa chính (Primary Key) - duy nhất, không null. Khóa ngoại (Foreign Key) - tham chiếu khóa chính bảng khác. Chuẩn hóa: 1NF (không lặp nhóm), 2NF (phụ thuộc đầy đủ), 3NF (không phụ thuộc bắc cầu).",
    "SQL cơ bản: SELECT, FROM, WHERE, GROUP BY, HAVING, ORDER BY, JOIN (INNER/LEFT/RIGHT/FULL). INSERT INTO, UPDATE SET, DELETE FROM. CREATE TABLE, ALTER TABLE, DROP TABLE.",
    "Cấu trúc dữ liệu: Mảng O(1) truy cập, O(n) tìm kiếm. Danh sách liên kết O(1) chèn/xóa đầu, O(n) truy cập. Stack: LIFO. Queue: FIFO. Tree: nhị phân tìm kiếm O(log n). Hash table: O(1) trung bình.",
    "Lập trình hướng đối tượng: Đóng gói (Encapsulation). Kế thừa (Inheritance). Đa hình (Polymorphism). Trừu tượng (Abstraction). Class là khuôn mẫu, Object là thể hiện. Constructor, Destructor.",
    "Mạng máy tính: IP address IPv4 (32 bit, 4 octet). IPv6 (128 bit). Subnet mask /24 = 255.255.255.0 (256 địa chỉ). MAC address 48 bit. TCP: hướng kết nối, đáng tin cậy. UDP: không kết nối, nhanh hơn.",
    "Hệ điều hành: Process vs Thread. Deadlock (điều kiện: Mutual exclusion, Hold&Wait, No preemption, Circular wait). Thuật toán CPU scheduling: FCFS, SJF, Round Robin, Priority. Virtual memory, Paging, Segmentation.",
    "An toàn thông tin: Mã hóa đối xứng (AES, DES - 1 khóa). Mã hóa bất đối xứng (RSA - khóa công khai/riêng tư). Hash: MD5, SHA-256 (một chiều). SSL/TLS: bảo mật HTTPS. Tấn công: SQL injection, XSS, CSRF, phishing.",
    "Trí tuệ nhân tạo: Machine Learning (học có giám sát, không giám sát, tăng cường). Deep Learning (mạng neural nhiều lớp). CNN (hình ảnh). RNN/LSTM (chuỗi thời gian). Transformer/Attention (NLP, GPT). Overfitting - Underfitting.",
]

# ═══════════════════════════════════════════════════════════════
# TỔNG HỢP KIẾN THỨC CHUNG
# ═══════════════════════════════════════════════════════════════
GENERAL_KB = [
    "Các nguyên tố hóa học quan trọng: H(1), He(2), Li(3), C(6), N(7), O(8), Na(11), Mg(12), Al(13), Si(14), P(15), S(16), Cl(17), K(19), Ca(20), Fe(26), Cu(29), Zn(30), Ag(47), Au(79), Pb(82).",
    "Hằng số vật lý: g=9.8 m/s² (gia tốc trọng trường). c=3×10⁸ m/s (tốc độ ánh sáng). h=6.626×10⁻³⁴ J·s (Planck). e=1.6×10⁻¹⁹ C (điện tích electron). N_A=6.022×10²³ mol⁻¹ (Avogadro). R=8.314 J/(mol·K).",
    "Địa lý thế giới: Châu Á (diện tích lớn nhất, đông dân nhất). Nga (nước lớn nhất: 17.1 triệu km²). Vatican (nhỏ nhất). Trung Quốc (đông dân nhất: 1.4 tỷ). Nile (sông dài nhất). Amazon (lưu lượng lớn nhất). Everest (8.849m).",
    "Kinh tế học: GDP = C + I + G + (X-M). Lạm phát (tăng giá). Giảm phát (giảm giá). Cung-cầu: giá tăng khi cầu tăng hoặc cung giảm. Thất nghiệp tự nhiên ~5%. Lãi suất tăng → vay tiền giảm → kinh tế chậm lại.",
    "Tư tưởng Hồ Chí Minh: Độc lập dân tộc gắn liền với CNXH. Đoàn kết toàn dân. Kết hợp sức mạnh dân tộc với sức mạnh thời đại. 'Không có gì quý hơn độc lập tự do'. 'Học, học nữa, học mãi'.",
    "Tiếng Anh - thì động từ: Simple Present (do/does). Simple Past (did, V-ed/V2). Future (will+V). Present Perfect (have/has+V3). Present Continuous (am/is/are+V-ing). Past Perfect (had+V3). Passive: be+V3.",
]

# ═══════════════════════════════════════════════════════════════
# EXPORT
# ═══════════════════════════════════════════════════════════════
from subject_detector import Subject

KNOWLEDGE_BASE: dict[Subject, List[str]] = {
    Subject.MATH:       MATH_KB,
    Subject.PHYSICS:    PHYSICS_KB,
    Subject.CHEMISTRY:  CHEMISTRY_KB,
    Subject.BIOLOGY:    BIOLOGY_KB,
    Subject.LITERATURE: LITERATURE_KB,
    Subject.HISTORY:    HISTORY_KB,
    Subject.GEOGRAPHY:  GEOGRAPHY_KB,
    Subject.IT:         IT_KB,
    Subject.GENERAL:    GENERAL_KB,
}

def get_kb_for_subject(subject: Subject) -> List[str]:
    """Trả về knowledge base cho môn học."""
    base = KNOWLEDGE_BASE.get(subject, GENERAL_KB)
    # Luôn kèm theo GENERAL_KB
    if subject != Subject.GENERAL:
        return base + GENERAL_KB
    return base

def get_all_kb() -> List[str]:
    """Trả về toàn bộ knowledge base."""
    all_docs = []
    seen = set()
    for docs in KNOWLEDGE_BASE.values():
        for d in docs:
            if d not in seen:
                all_docs.append(d)
                seen.add(d)
    return all_docs
