"""
prompt.py — Prompt Engine thông minh theo môn học

Chiến lược:
  1. System prompt chuyên biệt theo môn (từ subject_detector)
  2. Prompt CoT chuẩn (lần 1 + 2)
  3. Prompt few-shot mạnh (lần 3 hoặc khi confidence thấp)
  4. Context RAG + knowledge base inject
"""
from typing import List
from subject_detector import Subject, get_system_prompt

# ── Few-shot examples đa môn ────────────────────────────────
FEW_SHOT = {
    Subject.MATH: [
        ("Tập nghiệm của phương trình x² - 5x + 6 = 0 là:\nA. {1;6}  B. {2;3}  C. {-2;-3}  D. {1;2}",
         "Δ=25-24=1>0. x=(5±1)/2 → x₁=3, x₂=2. Vậy tập nghiệm là {2;3}.", "B"),
        ("Đạo hàm của f(x)=x³-3x tại x=2 là:\nA. 6  B. 9  C. 3  D. 12",
         "f'(x)=3x²-3. f'(2)=3·4-3=12-3=9.", "B"),
    ],
    Subject.PHYSICS: [
        ("Một vật có khối lượng 2kg, gia tốc 3m/s². Lực tác dụng là:\nA. 5N  B. 6N  C. 1.5N  D. 9N",
         "F=ma=2×3=6N.", "B"),
    ],
    Subject.CHEMISTRY: [
        ("Nguyên tử Na có số hiệu nguyên tử Z=11. Cấu hình electron là:\nA. 1s²2s²2p⁶3s²  B. 1s²2s²2p⁶3s¹  C. 1s²2s²2p⁵3s²  D. 1s²2s²2p⁶",
         "Na có 11e. Điền lần lượt: 1s²(2) 2s²(4) 2p⁶(10) 3s¹(11). Tổng =11.", "B"),
    ],
    Subject.LITERATURE: [
        ("Tác phẩm 'Tắt đèn' của ai?\nA. Nam Cao  B. Ngô Tất Tố  C. Nguyễn Du  D. Vũ Trọng Phụng",
         "'Tắt đèn' (1939) là tiểu thuyết hiện thực của Ngô Tất Tố, kể về chị Dậu trong nạn sưu thuế.", "B"),
    ],
    Subject.HISTORY: [
        ("Cách mạng tháng Tám 1945 thành công vào ngày:\nA. 2/9/1945  B. 19/8/1945  C. 3/2/1930  D. 7/5/1954",
         "Tổng khởi nghĩa tháng Tám bắt đầu tại Hà Nội ngày 19/8/1945. Ngày 2/9 là ngày đọc Tuyên ngôn Độc lập.", "B"),
    ],
    Subject.IT: [
        ("Độ phức tạp thuật toán tìm kiếm nhị phân là:\nA. O(n)  B. O(n²)  C. O(log n)  D. O(1)",
         "Tìm kiếm nhị phân chia đôi dãy mỗi lần → O(log n).", "C"),
    ],
}

GENERAL_FEW_SHOT = [
    ("Thủ đô của Việt Nam là:\nA. Đà Nẵng  B. Hải Phòng  C. Hà Nội  D. TP.HCM",
     "Hà Nội là thủ đô của Việt Nam từ năm 1010 (Lý Thái Tổ dời đô). Từ 1954 là thủ đô nước VNDCCH.", "C"),
    ("Nguyên tố nào chiếm tỉ lệ lớn nhất trong vỏ Trái Đất?\nA. Silic  B. Nhôm  C. Oxy  D. Sắt",
     "Oxy chiếm ~46% khối lượng vỏ Trái Đất. Silic ~28%. Nhôm ~8%. Sắt ~5%.", "C"),
]

def _format_examples(examples: list) -> str:
    parts = []
    for q, r, a in examples:
        parts.append(f"Câu hỏi:\n{q}\nSuy luận: {r}\nĐÁP ÁN: {a}")
    return "\n\n---\n\n".join(parts)


def build_messages(question_text: str, context: str,
                   subject: Subject, use_few_shot: bool = False) -> List[dict]:
    """
    Xây dựng chat messages tối ưu theo môn học.
    
    Args:
        question_text: Câu hỏi + A/B/C/D
        context:       RAG context (knowledge base + self-retrieval)
        subject:       Môn học đã detect
        use_few_shot:  True = thêm few-shot examples (dùng cho lần thứ 3
                       hoặc khi confidence thấp)
    """
    system = get_system_prompt(subject)

    # ── User prompt ─────────────────────────────────────────
    parts = []

    if use_few_shot:
        examples = FEW_SHOT.get(subject, []) + GENERAL_FEW_SHOT
        if examples:
            parts.append("## Ví dụ mẫu:\n\n" + _format_examples(examples[:2]))
            parts.append("")

    if context and context.strip():
        parts.append("## Kiến thức tham khảo liên quan:\n" + context.strip())
        parts.append("")

    parts.append("## Câu hỏi trắc nghiệm:")
    parts.append(question_text)
    parts.append("")
    parts.append("Hãy suy luận ngắn gọn (2-3 câu), loại trừ đáp án sai, rồi ghi:")
    parts.append("ĐÁP ÁN: [A/B/C/D]")

    user_content = "\n".join(parts)

    return [
        {"role": "system", "content": system},
        {"role": "user",   "content": user_content},
    ]
