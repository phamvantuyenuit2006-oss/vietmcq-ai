"""
reranker.py — Qwen3-Reranker-0.6B nâng cấp
"""
import torch
from pathlib import Path
from typing import List, Optional
from loguru import logger


class QwenReranker:
    def __init__(self, model_name="Qwen/Qwen3-Reranker-0.6B",
                 model_dir: Optional[Path] = None,
                 batch_size: int = 32, max_length: int = 512):
        self.batch_size = batch_size
        self.max_length = max_length
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        cache = str(model_dir) if model_dir else None

        try:
            from FlagEmbedding import FlagReranker
            self._m = FlagReranker(model_name,
                                   use_fp16=(self.device=="cuda"),
                                   cache_dir=cache)
            self._backend = "flag"
        except Exception:
            from transformers import AutoTokenizer, AutoModelForSequenceClassification
            dtype = torch.float16 if self.device=="cuda" else torch.float32
            self._tok = AutoTokenizer.from_pretrained(model_name, cache_dir=cache)
            self._mdl = AutoModelForSequenceClassification.from_pretrained(
                model_name, torch_dtype=dtype, cache_dir=cache
            ).to(self.device).eval()
            self._backend = "tf"

        logger.info(f"  ✅ QwenReranker ({self._backend})")

    def _score(self, query: str, docs: List[str]) -> List[float]:
        pairs = [[query, d] for d in docs]
        if self._backend == "flag":
            s = self._m.compute_score(pairs, normalize=True)
            return s if isinstance(s, list) else list(s)
        out = []
        for i in range(0, len(pairs), self.batch_size):
            b = pairs[i:i+self.batch_size]
            enc = self._tok([p[0] for p in b], [p[1] for p in b],
                            padding=True, truncation=True,
                            max_length=self.max_length, return_tensors="pt"
                           ).to(self.device)
            with torch.no_grad():
                out += torch.sigmoid(self._mdl(**enc).logits[:,0]).cpu().tolist()
        return out

    def rerank(self, query: str, docs: List[str], top_k: int = 6) -> List[str]:
        if not docs: return []
        if len(docs) <= top_k: return docs
        scores = self._score(query, docs)
        ranked = sorted(zip(scores, docs), reverse=True)
        return [d for _, d in ranked[:top_k]]
