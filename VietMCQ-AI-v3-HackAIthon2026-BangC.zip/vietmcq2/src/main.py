"""
main.py — Entry-point Docker Container
HackAIthon 2026 — Bang C: INNOVATOR
Doc: /data/public_test.csv hoac /data/private_test.csv
Ghi: /output/pred.csv (qid, answer)
"""
import sys, os, argparse, pandas as pd
from pathlib import Path
from loguru import logger

sys.path.insert(0, str(Path(__file__).parent))
from config import Config
from utils import load_test_csv
from pipeline import MCQPipeline

logger.remove()
logger.add(sys.stderr,
    format="<green>{time:HH:mm:ss}</green> | <level>{level:<7}</level> | {message}",
    colorize=True, level="INFO")

def find_input(d: Path) -> Path:
    for n in ["public_test.csv","private_test.csv","test.csv"]:
        p = d / n
        if p.exists():
            logger.info(f"Input: {p}"); return p
    csvs = list(d.glob("*.csv"))
    if csvs: return csvs[0]
    raise FileNotFoundError(f"Khong tim thay CSV trong {d}")

def save(pred: pd.DataFrame, out: Path) -> None:
    bad = ~pred["answer"].isin({"A","B","C","D"})
    if bad.any(): pred.loc[bad,"answer"] = "A"
    out.parent.mkdir(parents=True, exist_ok=True)
    pred[["qid","answer"]].to_csv(out, index=False)
    logger.info(f"Saved: {out} ({len(pred)} rows)")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir",    type=Path, default=Path("/data"))
    p.add_argument("--output-dir",  type=Path, default=Path("/output"))
    p.add_argument("--model-dir",   type=Path, default=Path("/app/models"))
    p.add_argument("--llm-model",   type=str,  default="Qwen/Qwen3.5-7B-Instruct")
    p.add_argument("--batch-size",  type=int,  default=None)
    p.add_argument("--n-samples",   type=int,  default=3)
    p.add_argument("--no-rag",      action="store_true")
    p.add_argument("--no-kb",       action="store_true")
    p.add_argument("--no-ensemble", action="store_true")
    p.add_argument("--debug",       action="store_true")
    args = p.parse_args()

    logger.info("=" * 60)
    logger.info("  VietMCQ-AI v3.0 | HackAIthon 2026 | Bang C INNOVATOR")
    logger.info("=" * 60)

    cfg = Config.from_env()
    cfg.data_dir         = args.data_dir
    cfg.output_dir       = args.output_dir
    cfg.model_dir        = args.model_dir
    cfg.llm_model        = args.llm_model
    cfg.use_rag          = not args.no_rag
    cfg.use_kb           = not args.no_kb
    cfg.n_samples        = args.n_samples
    cfg.ensemble_enabled = not args.no_ensemble
    cfg.debug            = args.debug
    if args.batch_size:  cfg.batch_size = args.batch_size

    logger.info(f"  rag={cfg.use_rag} | kb={cfg.use_kb} | "
                f"ensemble={cfg.ensemble_enabled}(n={cfg.n_samples}) | "
                f"batch={cfg.batch_size}")

    df = load_test_csv(find_input(cfg.data_dir))
    logger.info(f"  Loaded {len(df)} cau\n")

    pipeline = MCQPipeline(cfg)
    pred     = pipeline.predict(df)
    save(pred, cfg.output_dir / "pred.csv")
    logger.info("Done!")

if __name__ == "__main__":
    main()
