"""
retriever.py — Hybrid Retriever: Knowledge Base + Self-Retrieval

Hai nguồn context:
  1. Knowledge Base nhúng sẵn (kiến thức chuyên môn)
  2. Self-retrieval từ bộ đề (câu hỏi tương tự)

Chiến lược phân chia:
  - KB: retrieve top-10 (kiến thức domain)
  - Self: retrieve top-10 (câu hỏi liên quan)
  - Rerank tổng hợp → top-6
"""
import numpy as np, faiss, torch
from pathlib import Path
from typing import List, Optional
from loguru import logger


class HybridRetriever:
    def __init__(self, model_name="BAAI/bge-m3",
                 model_dir: Optional[Path] = None,
                 use_fp16: bool = True):
        device = "cuda" if torch.cuda.is_available() else "cpu"
        cache  = str(model_dir) if model_dir else None

        try:
            from FlagEmbedding import BGEM3FlagModel
            self._model = BGEM3FlagModel(
                model_name, use_fp16=(use_fp16 and device=="cuda"),
                cache_dir=cache)
            self._backend = "flag"
        except ImportError:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(model_name, device=device,
                                              cache_folder=cache)
            self._backend = "st"

        # Hai index riêng biệt
        self._kb_index:   faiss.Index = None
        self._self_index: faiss.Index = None
        self._kb_corpus:   List[str] = []
        self._self_corpus: List[str] = []

        logger.info(f"  ✅ HybridRetriever ({self._backend}, device={device})")

    def _encode(self, texts: List[str], bs: int = 256) -> np.ndarray:
        if self._backend == "flag":
            out  = self._model.encode(texts, batch_size=bs, max_length=512,
                                      return_dense=True, return_sparse=False,
                                      return_colbert_vecs=False)
            vecs = out["dense_vecs"].astype(np.float32)
        else:
            vecs = self._model.encode(texts, batch_size=bs,
                                      normalize_embeddings=True,
                                      show_progress_bar=False).astype(np.float32)
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        return vecs / np.maximum(norms, 1e-8)

    def _build(self, corpus: List[str]) -> faiss.Index:
        vecs = self._encode(corpus)
        dim  = vecs.shape[1]
        if len(corpus) > 8000:
            nlist = min(512, len(corpus)//20)
            q = faiss.IndexFlatIP(dim)
            idx = faiss.IndexIVFFlat(q, dim, nlist, faiss.METRIC_INNER_PRODUCT)
            idx.train(vecs); idx.nprobe = 32
        else:
            idx = faiss.IndexFlatIP(dim)
        idx.add(vecs)
        return idx

    def build_kb_index(self, kb_docs: List[str]) -> None:
        """Build index từ knowledge base nhúng sẵn."""
        self._kb_corpus = kb_docs
        logger.info(f"  Building KB index: {len(kb_docs)} docs...")
        self._kb_index = self._build(kb_docs)
        logger.info(f"  ✅ KB index: {self._kb_index.ntotal} vecs")

    def build_self_index(self, questions: List[str]) -> None:
        """Build index từ bộ câu hỏi (self-retrieval)."""
        self._self_corpus = questions
        logger.info(f"  Building self-retrieval index: {len(questions)} docs...")
        self._self_index = self._build(questions)
        logger.info(f"  ✅ Self index: {self._self_index.ntotal} vecs")

    def _search_one(self, idx: faiss.Index, corpus: List[str],
                    q_vec: np.ndarray, top_k: int,
                    query_text: str = "", threshold: float = 0.1) -> List[str]:
        if idx is None or not corpus: return []
        k = min(top_k + 2, len(corpus))
        scores, idxs = idx.search(q_vec, k)
        results = []
        for s, i in zip(scores[0], idxs[0]):
            if i < 0 or float(s) < threshold: continue
            doc = corpus[i]
            if doc.strip()[:60] == query_text.strip()[:60]: continue
            results.append(doc)
            if len(results) >= top_k: break
        return results

    def batch_retrieve(self, queries: List[str],
                       kb_top_k: int = 10,
                       self_top_k: int = 10) -> List[str]:
        """
        Retrieve context cho từng query, kết hợp KB + self-retrieval.
        Trả về list context string tương ứng từng query.
        """
        if not queries: return []

        q_vecs = self._encode(queries)
        results = []

        for i, (q_text, q_vec) in enumerate(zip(queries, q_vecs)):
            q_vec_2d = q_vec.reshape(1, -1)

            # KB retrieval
            kb_docs = self._search_one(self._kb_index, self._kb_corpus,
                                       q_vec_2d, kb_top_k, "", 0.05)

            # Self retrieval
            self_docs = self._search_one(self._self_index, self._self_corpus,
                                         q_vec_2d, self_top_k, q_text, 0.15)

            # Ghép: KB trước (kiến thức nền), self sau (câu hỏi liên quan)
            all_docs = kb_docs + self_docs
            results.append(all_docs)

        return results   # List[List[str]]
