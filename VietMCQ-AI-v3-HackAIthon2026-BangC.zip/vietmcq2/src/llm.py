"""
llm.py — Qwen3.5-Instruct Inference Engine (tối ưu tuyệt đối)
"""
import torch
from pathlib import Path
from typing import List, Optional
from loguru import logger

def _vram_gb() -> float:
    try:
        if torch.cuda.is_available():
            _, total = torch.cuda.mem_get_info(0)
            return total / 1024**3
    except Exception: pass
    return 0.0

def _pick(requested: str, vram: float):
    """(model_id, load_in_8bit)"""
    if "7B" in requested or "7b" in requested:
        if vram >= 14: return requested, False
        if vram >= 9:  return requested, True    # INT8
        if vram >= 6:  return "Qwen/Qwen3.5-3B-Instruct", False
        return "Qwen/Qwen3.5-1.5B-Instruct", False
    if "3B" in requested or "3b" in requested:
        if vram >= 6: return requested, False
        return "Qwen/Qwen3.5-1.5B-Instruct", False
    return "Qwen/Qwen3.5-1.5B-Instruct", False


class QwenLLM:
    """
    Qwen3.5-Instruct với tất cả tối ưu:
      - Flash Attention 2
      - Batch inference, left-padding
      - enable_thinking=False (tiết kiệm ~30% token)
      - Greedy decoding
      - OOM auto-split
      - Adaptive quantization (auto INT8 nếu cần)
    """
    def __init__(self, model_name="Qwen/Qwen3.5-7B-Instruct",
                 model_dir: Optional[Path] = None,
                 max_new_tokens: int = 220):
        self.max_new_tokens = max_new_tokens
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        cache = str(model_dir) if model_dir else None
        vram  = _vram_gb()

        actual, use_8bit = _pick(model_name, vram)
        logger.info(f"  LLM: {actual.split('/')[-1]} | VRAM={vram:.1f}GB | 8bit={use_8bit}")

        from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig

        self.tokenizer = AutoTokenizer.from_pretrained(
            actual, cache_dir=cache, trust_remote_code=True,
            padding_side="left")
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token_id = self.tokenizer.eos_token_id

        dtype  = torch.float16 if self.device == "cuda" else torch.float32
        kwargs = dict(cache_dir=cache, trust_remote_code=True, torch_dtype=dtype,
                      device_map="auto" if self.device=="cuda" else None)
        if use_8bit:
            kwargs["quantization_config"] = BitsAndBytesConfig(load_in_8bit=True)

        try:
            kwargs["attn_implementation"] = "flash_attention_2"
            self.model = AutoModelForCausalLM.from_pretrained(actual, **kwargs)
            logger.info("  ⚡ Flash Attention 2")
        except Exception:
            kwargs.pop("attn_implementation", None)
            self.model = AutoModelForCausalLM.from_pretrained(actual, **kwargs)

        if self.device == "cpu": self.model = self.model.to("cpu")
        self.model.eval()
        logger.info(f"  ✅ LLM ready")

    def _templatize(self, messages_list: List[List[dict]]) -> List[str]:
        out = []
        for msgs in messages_list:
            try:
                t = self.tokenizer.apply_chat_template(
                    msgs, tokenize=False, add_generation_prompt=True,
                    enable_thinking=False)
            except TypeError:
                t = self.tokenizer.apply_chat_template(
                    msgs, tokenize=False, add_generation_prompt=True)
            out.append(t)
        return out

    def generate_batch(self, messages_list: List[List[dict]]) -> List[str]:
        texts  = self._templatize(messages_list)
        inputs = self.tokenizer(texts, return_tensors="pt", padding=True,
                                truncation=True, max_length=2048)
        if self.device == "cuda":
            inputs = {k: v.cuda() for k, v in inputs.items()}

        with torch.no_grad():
            try:
                out_ids = self.model.generate(
                    **inputs, max_new_tokens=self.max_new_tokens,
                    do_sample=False, temperature=1.0,
                    pad_token_id=self.tokenizer.pad_token_id,
                    eos_token_id=self.tokenizer.eos_token_id,
                    use_cache=True, repetition_penalty=1.05)
            except RuntimeError as e:
                if "out of memory" in str(e).lower() and len(messages_list) > 1:
                    torch.cuda.empty_cache()
                    mid = len(messages_list) // 2
                    return (self.generate_batch(messages_list[:mid]) +
                            self.generate_batch(messages_list[mid:]))
                raise

        in_len = inputs["input_ids"].shape[1]
        return [
            self.tokenizer.decode(o[in_len:], skip_special_tokens=True).strip()
            for o in out_ids
        ]
